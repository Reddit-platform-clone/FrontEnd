// import React, { useState, useEffect } from 'react';
// import './Message.css';

// function Message() {

//     return(

// <div className='storedmsg'>
//  <div className='subtitle'>
//     <p>{subject}</p>
//  </div>
//  <div className='msgbody'>
//     <div className='upperpart'>
//      <p>from</p><p>{username}</p><p>sent</p><p>{time}</p>
//     </div>
//     <div className='msgcontent'>
//      <p>{message}</p>
//     </div>
//     <div className='lowerpart'>
//      <button>Permalink</button>
//      <button>Delete</button>
//      <button>Report</button>
//      <button>Block User</button>
//      <button>Mark Unread</button>
//      <button>Reply</button>
//     </div>
//  </div>
// </div>

//     );
// }
// export default Message;